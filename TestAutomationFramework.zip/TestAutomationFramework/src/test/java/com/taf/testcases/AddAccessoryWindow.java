package com.taf.testcases;

import java.io.IOException;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.taf.utilities.GlobalMethods;

public class AddAccessoryWindow{
	
	@Test
	public void addAccessory() throws InterruptedException, IOException
	{	
		System.out.println("addAccessory window: "+Thread.currentThread().getId());
		/*String tcName="AddAccessory_01";
		Actions build=new Actions(driver);
	
		
		startTAF(tcName);
		driver.get("http://store.demoqa.com");
		WebElement productNav=driver.findElement(By.xpath("//a[normalize-space()='Product Category']"));
		waitUntilVisible(productNav, 20);
		driver.navigate().refresh();
		productNav.click();
		mouseHover(productNav);
		String parent=driver.getWindowHandle();
		System.out.println("Parent: "+parent);
		Actions act=new Actions(driver);
		act.keyDown(Keys.CONTROL).click().keyUp(Keys.CONTROL).build().perform();
		Set<String> windows=driver.getWindowHandles();

		for(String s:windows)
		{
			System.out.println("Window name: "+s);
			if(!s.equalsIgnoreCase(parent))
			{
				System.out.println("Inside if stmt");
				driver.switchTo().window(s);
				break;
			}
		}
		//driver.switchTo().window(parent);
		driver.findElement(By.xpath("//a[normalize-space()='Accessories']")).click();
		
		WebElement accessory=driver.findElement(By.xpath("//h2[normalize-space()='Magic Mouse']"));
		waitUntilVisible(accessory, 20);
		
		driver.findElement(By.xpath("//h2[normalize-space()='Magic Mouse']/..//input[@value='Add To Cart']")).click();
		Thread.sleep(4000);
		
		String itemPrice=driver.findElement(By.xpath("//h2[normalize-space()='Magic Mouse']/..//span[starts-with(@class,'currentprice')]")).getText().trim();
		driver.findElement(By.xpath("//a[@title='Checkout']")).click();
		String cartItem=driver.findElement(By.xpath("//table[@class='checkout_cart']//tr[2]//td[2]")).getText().trim();
		String cartItemPrice=driver.findElement(By.xpath("//table[@class='checkout_cart']//tr[2]//td[5]")).getText().trim();

		Assert.assertEquals(cartItem, "Magic Mouse");
		Assert.assertEquals(itemPrice, cartItemPrice);
		System.out.println("Data 2 for Tc: "+getData("data2"));
		*/

	}

}
