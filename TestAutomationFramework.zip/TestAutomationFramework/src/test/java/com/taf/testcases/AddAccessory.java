package com.taf.testcases;

import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.Assert.*;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.relevantcodes.extentreports.LogStatus;
import com.taf.objectRepository.HomePage;
import com.taf.utilities.GlobalMethods;
import com.taf.utilities.LoadTaf;

public class AddAccessory extends GlobalMethods{
	
	@Test
	public void addAccessory() throws InterruptedException, IOException
	{	
		//System.out.println("addAccessory: "+Thread.currentThread().getId());

		String tcName="AddAccessory_01";
		startTAF(tcName);
		
		driver.get("http://store.demoqa.com");
		HomePage homepage=new HomePage();
		
		//logger.log(LogStatus.PASS, "Step 1");
		waitUntilVisible(homepage.navProductCategory, 20);
		mouseHover(homepage.navProductCategory);
		//logger.log(LogStatus.FAIL, "Step 2");
		waitUntilVisible(homepage.linkAccessories, 20);
		homepage.actionClickAccessories();
		Thread.sleep(10000);
		homepage.actionClickHome();
		waitUntilVisible(homepage.slideThree, 20);
		homepage.actionClickIpodNano();
		logger.log(LogStatus.WARNING, "Step 3");
		driver.findElement(By.xpath("//h2[normalize-space()='Magic Mouse']/..//input[@value='Add To Cart']")).click();
		Thread.sleep(4000);
		
		String itemPrice=driver.findElement(By.xpath("//h2[normalize-space()='Magic Mouse']/..//span[starts-with(@class,'currentprice')]")).getText().trim();
		driver.findElement(By.xpath("//a[@title='Checkout']")).click();
		String cartItem=driver.findElement(By.xpath("//table[@class='checkout_cart']//tr[2]//td[2]")).getText().trim();
		String cartItemPrice=driver.findElement(By.xpath("//table[@class='checkout_cart']//tr[2]//td[5]")).getText().trim();

		Assert.assertEquals(cartItem, "Magic Mouse"); 
		Assert.assertEquals(itemPrice, cartItemPrice);
		//logger.log(LogStatus.PASS, "Step 4");
		System.out.println("Data 2 for Tc: "+getData("data2"));
		
		

	}

}
