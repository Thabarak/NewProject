package com.taf.stepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.taf.objectRepository.HomePage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AddAccessories {

	WebDriver driver;
	HomePage homepage=new HomePage();
	
@Given("^User present in home page$")
public void User_present_in_home_page()
{
	System.out.println("Before Test in execution...");
	System.setProperty("webdriver.chrome.driver", "G:\\chromedriver.exe");
	driver=new ChromeDriver();
	driver.get("http://store.demoqa.com");
}
@When("User add any accessory")
public void user_add_any_accessory() {
    // Write code here that turns the phrase above into concrete actions
}

@Then("Accessory added to cart")
public void accessory_added_to_cart() {
    // Write code here that turns the phrase above into concrete actions
}
}
