package com.taf.objectRepository;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.taf.utilities.GlobalVariables;

public class HomePage extends GlobalVariables {

	
	//Page Objects
	@FindBy(xpath="//a[normalize-space()='Home']") public WebElement navHome;
	@FindBy(xpath="//a[normalize-space()='Product Category']") public WebElement navProductCategory;
	@FindBy(xpath="//nav[@id='main-nav']//a[normalize-space()='Accessories']") public WebElement linkAccessories;
	@FindBy(xpath="//nav[@id='main-nav']//a[normalize-space()='iMacs']") public WebElement linkImacs;
	@FindBy(xpath="//nav[@id='main-nav']//a[normalize-space()='iPads']") public WebElement linkIpads;
	@FindBy(xpath="//nav[@id='main-nav']//a[normalize-space()='iPods']") public WebElement linkIpods;
	@FindBy(xpath="//nav[@id='main-nav']//a[normalize-space()='MacBooks']") public WebElement linkMacbooks;
	@FindBy(xpath="//a[normalize-space()='All Product']") public WebElement navAllProduct;
	@FindBy(xpath="//a[@title='Checkout']") public WebElement linkCheckout;
	@FindBy(xpath="//a[@title='My Account']") public WebElement linkMyAccount;
	@FindBy(xpath="//img[@alt='home']") public WebElement imgHome;
	@FindBy(xpath="//input[@value='Search Products']") public WebElement inputSearch;
	@FindBy(xpath="//ul[@id='slide_menu']//a[3]") public WebElement slideThree;
	@FindBy(xpath="//div[@id='slides']//img[@alt='iPod Nano Blue']") public WebElement imgIpodNanoBlue;


	public HomePage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public void actionClickAccessories()
	{
		try {
			linkAccessories.click();
		}catch(Exception e) {
			System.out.println("Exception in actionClickAccessories: "+e.getMessage().substring(0, 100));
		}
	}
	public void actionClickHome()
	{
		try {
			navHome.click();
		}catch(Exception e) {
			System.out.println("Exception in actionClickHome: "+e.getMessage().substring(0, 100));
		}
	}
	public void actionClickIpodNano()
	{
		try {
			imgIpodNanoBlue.click();
		}catch(Exception e) {
			System.out.println("Exception in actionClickIpodNano: "+e.getMessage().substring(0, 100));
		}
	}
}
