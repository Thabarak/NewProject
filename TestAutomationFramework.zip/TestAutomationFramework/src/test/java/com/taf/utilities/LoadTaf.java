package com.taf.utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class LoadTaf extends GlobalVariables {

	@BeforeTest
	public void beforeTest()
	{
		System.out.println("Before Test in execution...");
		System.setProperty("webdriver.chrome.driver", "G:\\chromedriver.exe");
		extent=new ExtentReports(System.getProperty("user.dir")+"/output/newfile.html",true);
		extent.addSystemInfo("Environment", "Testing env");
		extent.addSystemInfo("User name","Thabarak");
		
		
	}
	@BeforeMethod
	public void beforeMethod()
	{
		System.out.println("------------Test Execution started---------------");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	@AfterMethod
	public void afterMethod(ITestResult result)
	{
		
		System.out.println("After method in execution...");
		if(result.getStatus()==ITestResult.FAILURE)
		{
			logger.log(LogStatus.FAIL, "Test case failed");
		}
		//driver.close();
		//driver.quit();
		dataset.clear();
		extent.endTest(logger);
		
	}
	@AfterTest
	public void afterTest()
	{		
		System.out.println("After Test in execution...");
		extent.flush();
		extent.close();
	}
	public static void startTAF(String tcName) throws IOException
	{
		excelLoader(tcName);
		logger=extent.startTest(tcName);
		
	}
	public static HashMap<String, String> excelLoader(String tcName)
	{
		System.out.println("Excel data loading...");
		try {
		FileInputStream fis=new FileInputStream(new File("G://data.xlsx"));
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet=wb.getSheetAt(0);
		dataset=new HashMap<String, String>();

		for(int i=0;i<sheet.getLastRowNum();i++)
		{
			
		String testcase=sheet.getRow(i).getCell(0).getStringCellValue();
		if(testcase.equalsIgnoreCase(tcName))
		{
			for(int j=0;j<sheet.getRow(i).getLastCellNum();j++)
			{
				String columnvalue=sheet.getRow(0).getCell(j).getStringCellValue();
				String data=sheet.getRow(i).getCell(j).getStringCellValue();
				dataset.put(columnvalue, data);
			}
			break;
		}
		}
		wb.close();
		fis.close();
		return dataset;
		}
		catch(Exception e)
		{
			System.out.println("Exception in method waitUntilVisible: "+e.getMessage().substring(0, 100));
			return null;
		}
	}
	public static void extentReportGenerater()
	{
		
	}
}
