package com.taf.utilities;

import java.util.Map;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GlobalMethods extends LoadTaf{

	public static void waitUntilVisible(WebElement element, long timeUnitInSec)
	{
		try {
		WebDriverWait wait=new WebDriverWait(driver, timeUnitInSec);
		wait.until(ExpectedConditions.visibilityOf(element));}
		catch(Exception e)
		{
			System.out.println("Exception in method waitUntilVisible: "+e.getMessage().substring(0, 100));
		}
	}
	public static void mouseHover(WebElement element)
	{
		try {
		Actions act=new Actions(driver);
		act.moveToElement(element).perform();
		}
		catch(Exception e)
		{
			System.out.println("Exception in method mouseHover: "+e.getMessage().substring(0, 100));
		}
	}
	public static String getData(String column)
	{
		try {
			for(Map.Entry<String, String> entry:dataset.entrySet())
			{
				if(entry.getKey().equalsIgnoreCase(column))
					return entry.getValue();
			}	
		}
		catch(Exception e)
		{
			System.out.println("Exception in method getData: "+e.getMessage().substring(0, 100));
		}
		return null;
	}
}
