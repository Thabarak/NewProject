package com.taf.utilities;

import java.util.HashMap;
import org.openqa.selenium.WebDriver;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

public class GlobalVariables {

	public static WebDriver driver=null;
	public static HashMap<String, String> dataset=null;
	public static ExtentReports extent=null;
	public static ExtentTest logger=null;
}
